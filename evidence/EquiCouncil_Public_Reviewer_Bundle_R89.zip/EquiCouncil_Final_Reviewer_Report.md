# EquiCouncil — Final Devnet Verification Report

**Status:** Controlled nine-transaction lifecycle complete; final R88 saved-evidence freeze passed.  
**Network:** GenLayer Studio Devnet, chain ID `61997`  
**Contract:** `0xc948f6411C3D3CF10C8fF9927E0932B2d8d3b438`  
**Session:** `session:1`  
**Final state:** `RATIFIED`, three of three approvals  
**Finalizing transaction:** `0xcac7d826794b2f1d414d73a80a64f2d8dc32addef8ebf7c02d2d3a62fddff4c7`

## Executive summary

EquiCouncil is a bounded, noncustodial resource negotiation Intelligent Contract for three participants. Each participant provides permitted resource bounds and a plain-language explanation of urgency. GenLayer nondeterministic execution assigns one bounded urgency weight per participant; independent validators assess the decision-critical weights. The contract then computes a feasible allocation using deterministic rules. No individual participant may finalize the allocation unilaterally: all three must ratify before finalization.

The controlled Studio Devnet demonstration completed its nine planned contract writes. The final transaction's independent verification showed a successful EVM receipt, GenLayer `FINALIZED` consensus and `FINISHED_WITH_RETURN` execution. The final contract session and round are `RATIFIED`, all three approvals remain true, and the final account nonces were A47, B2 and C2.

## Demonstrated workflow

| Step | Actor | Operation | Observed or intended outcome |
|---:|---|---|---|
| 1 | A | `create_session` | Opened `session:1` |
| 2 | B | `join_session` | Two participants |
| 3 | C | `join_session` | Three participants |
| 4 | A | `lock_session` | Frozen inputs and constraints |
| 5 | A | `evaluate_allocations` | Proposed allocation after validator-checked urgency classification |
| 6 | A | `ratify_proposal` | First approval |
| 7 | B | `ratify_proposal` | Second approval |
| 8 | C | `ratify_proposal` | Third approval, session still `PROPOSED` |
| 9 | A | `finalize_session` | Finalized a unanimously approved allocation; session `RATIFIED` |

The demonstrated pool held **6 units**, with observed urgency weights **[1, 2, 3]** and resulting allocation **[1, 2, 3]**. The weight classification was nondeterministic, while the bounded allocation and approval checks were deterministic.

## Final independent evidence

- **Step-9 transaction:** `0xcac7d826794b2f1d414d73a80a64f2d8dc32addef8ebf7c02d2d3a62fddff4c7`
- **Step-9 nonce:** participant A, nonce `46`; independently recorded account transition `46/46` to `47/47`.
- **Step-9 receipt and consensus:** EVM receipt status `1`; GenLayer consensus `FINALIZED`; Studio execution `FINISHED_WITH_RETURN`.
- **Step-9 finality certificate SHA-256:** `620555b46b066e9b3a8154d15ff825d1df22b3d7b8a6ad1d351237f5ef48f94e`.
- **Step-9 actual outlay:** `78,629,000,000,823` wei against an original maximum `200,000,000,000,000` wei.
- **R88 verification:** `R88_STATUS=PASS_OFFLINE_FINAL_HANDOFF`, with **63 preserved step-9 RPC responses** checked and **zero new network calls or blockchain writes**.
- **R88 public JSON SHA-256:** `b208f136b538719b3ed6c9be49a5a142ccc0c728355aee31d0fb2247ff251f42`.
- **R88 public handoff SHA-256:** `a7340e9614142244e43fcf95b4e633106f21b3391ba85f3971c6a39755462ff8`.

The per-transaction sum for steps 6–9 is a **partial lifecycle cost**, not a total for all nine writes. Full raw evidence for steps 1–5 was verified in earlier stages and inherited through the pinned release lineage; R88 does not independently re-audit every early receipt.

## Why GenLayer is technically relevant

The natural-language urgency classification requires semantic assessment rather than simple numeric input. The contract delegates only bounded urgency labels to nondeterministic validator execution. Resource conservation, min/max bounds, allocation arithmetic, unanimous approval and allowed state transitions remain deterministic. This structure limits what the AI can decide and makes the material decision outputs verifiable by independent validators.

## Exceptions and scope limitations

These points are recorded and should remain disclosed in reviewer materials:

1. Participant A's historical nonce `36` remains unidentified in the preserved forensic record.
2. Participant A's nonce `45` was observed/indexed but does not have a separate independent finality verification in this project's record.
3. Step 8's original executor reported a post-state mismatch despite a finalized transaction; R82 reconciled that the correct post-step-8 status was `PROPOSED` with three approvals, not `RATIFIED`.
4. Prior one-shot and read-only stops were preserved; they were not silently overwritten or retried.
5. This is a **Studio Devnet** demonstration and an audit of saved evidence, **not** a mainnet deployment or independent third-party security audit.

## Publication boundary

The public bundle should include only R88's `public-evidence.json`, `FINAL_EVIDENCE_HANDOFF.md`, `SHA256SUMS.txt`, this report, and a minimal reviewer README/manifest. Do **not** include signer material, seed phrases, account files, transaction-signing journals, raw RPC responses, or complete internal working directories.

**Still to provide for an external project submission:** a verified public source-repository link, a verified frontend/demo URL if one exists, and an actual video link if recorded. No link should be invented. The final on-chain demonstration itself needs no further blockchain transactions.
