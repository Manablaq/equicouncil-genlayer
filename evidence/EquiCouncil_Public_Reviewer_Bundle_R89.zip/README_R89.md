# EquiCouncil — Public Reviewer Bundle R89

This contains an allowlisted copy of the completed R88 public evidence and a reviewer report. All nine planned Studio Devnet writes are certified. The last session state is RATIFIED with 3/3 approvals.

Contract: `0xc948f6411C3D3CF10C8fF9927E0932B2d8d3b438`

Final transaction: `0xcac7d826794b2f1d414d73a80a64f2d8dc32addef8ebf7c02d2d3a62fddff4c7`

The preserved raw RPC files and signer materials are **not** distributed. Historical nonce 36 is unresolved; nonce 45 lacks separate independent finality verification.

The SHA256SUMS.txt file belongs to R88 and checks only its two public files. MANIFEST_R89_SHA256SUMS.txt checks every public file in this distribution.

**Not verified yet:** a public source repository, hosted frontend/demo URL or demo video. This is a Devnet demonstration, not a mainnet deployment or third-party audit.
