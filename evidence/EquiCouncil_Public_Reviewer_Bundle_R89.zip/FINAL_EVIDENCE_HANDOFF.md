# EquiCouncil — final on-chain lifecycle evidence

## Result

**9/9 planned lifecycle transactions certified.** The final session is `RATIFIED` with **3/3 approvals** on GenLayer Studio Devnet (chain 61997).

**Contract:** `0xc948f6411C3D3CF10C8fF9927E0932B2d8d3b438`
**Session:** `session:1`
**Final transaction:** `0xcac7d826794b2f1d414d73a80a64f2d8dc32addef8ebf7c02d2d3a62fddff4c7`
**Final step actual outlay:** `78629000000823 wei` (cap `200000000000000 wei`)
**Finality SHA-256:** `620555b46b066e9b3a8154d15ff825d1df22b3d7b8a6ad1d351237f5ef48f94e`

## Four most recent lifecycle writes

| Step | Signer | Operation | Transaction hash | Actual outlay (wei) |
|---|---|---|---|---:|
| 6 | A | `ratify_proposal` | `0xb6a846c0f85b6f30747e4aebe68aec99e9928223d6afb6b55ca0238aacac3ad6` | 78628500000823 |
| 7 | B | `ratify_proposal` | `0x1bc23084161bc559a5c63199883b90814f6171788423b92d963a8168499e2963` | 78628500000823 |
| 8 | C | `ratify_proposal` | `0x22e03ae1319f6f21b4d109e704aaba17f8e0644686502bcdba23bd56e71d9b50` | 78628500000823 |
| 9 | A | `finalize_session` | `0xcac7d826794b2f1d414d73a80a64f2d8dc32addef8ebf7c02d2d3a62fddff4c7` | 78629000000823 |

Steps 1–5 were finalized and verified in earlier stages. R88 checks the pinned final release lineage, not a new independent re-examination of their individual raw receipts.

## Reviewer verification

Inspect the on-chain transaction and check that the final session is `RATIFIED` with three approvals. Compare the SHA-256 of the preserved private certificate with the public hash above. The audit of saved responses is performed entirely offline.

## Historical exceptions (disclosed)

- Participant A nonce 36 remains unidentified in the historic forensic record.
- Participant A nonce 45 was indexed but was not independently finalized under the project review.
- Step 8 initially stopped in post-state verification after a successful finalized transaction; R82 independently reconciled the expected `PROPOSED`/3 approvals boundary.
- R74 stopped before signing; its execution directory was not rerun.
- R83/R84 read-only preflights stopped; R85 resolved the fee-specific issue.

## Publication and privacy

This is a public proof summary. It does not contain private keys, full private execution journals or RPC payloads. Preserve original R9–R87 evidence locally. Do not publish private signer directories or wallet secrets.

## Scope

Devnet demonstration and saved-evidence audit, not an independent third-party security audit or mainnet deployment. No additional live transaction is needed for the nine-step lifecycle.
